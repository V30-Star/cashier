

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center mt-5" style="overflow-x: auto;">
        <div class="col-md table-container">
            <table class="table table-striped table-bordered nowrap" id="tableList" style="width:100%">
                <thead>
                    <tr>
                        <th>Nama Barang</th>
                        <th>Jumlah Barang</th>
                        <th>Harga Barang</th>
                        <th>Pengirim Barang</th>
                        <th>Deskripsi Barang</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $BuatBarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($BuatBarang->nama_barang); ?></td>
                            <td><?php echo e($BuatBarang->jumlah_barang); ?></td>
                            <td><?php echo e($BuatBarang->harga_barang); ?></td>
                            <td><?php echo e($BuatBarang->pengirim_barang); ?></td>
                            <td><?php echo e($BuatBarang->deskripsi_barang); ?></td>
                            <td>Action Button Here</td> <!-- Tambahkan tombol action sesuai kebutuhan -->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\casa\resources\views/main/lihatBarang.blade.php ENDPATH**/ ?>