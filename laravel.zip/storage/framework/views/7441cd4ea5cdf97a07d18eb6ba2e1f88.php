

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h4 class="mb-3 text-center">Edit Barang</h4>

                <hr class="my-4">

                <form class="needs-validation" method="POST" action="<?php echo e(route('updateBarang', $barang->kode_barang)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="mb-3">
                        <label for="kode_barang" class="form-label">Kode Barang</label>
                        <input type="text" class="form-control" id="kode_barang" name="kode_barang"
                            value="<?php echo e($barang->kode_barang); ?>" disabled>
                    </div>

                    <div class="mb-3">
                        <label for="nama_barang" class="form-label">Nama Barang</label>
                        <input type="text" class="form-control" id="nama_barang" name="nama_barang"
                            value="<?php echo e($barang->nama_barang); ?>" disabled>
                    </div>

                    <div class="mb-3">
                        <label for="harga_barang" class="form-label">Harga Barang</label>
                        <input type="text" class="form-control" id="harga_barang" name="harga_barang"
                            value="<?php echo e($barang->harga_barang); ?>">
                    </div>

                    <div class="mb-3">
                        <label for="stok_barang" class="form-label">Stok Barang</label>
                        <input type="text" class="form-control" id="stok_barang" name="stok_barang"
                            value="<?php echo e($barang->stok_barang); ?>">
                    </div>

                    <button class="w-100 btn btn-primary btn-lg" type="submit">Simpan Perubahan</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kasa\resources\views/main/editBarang.blade.php ENDPATH**/ ?>