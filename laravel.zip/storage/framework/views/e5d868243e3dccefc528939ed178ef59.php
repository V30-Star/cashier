

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h2>Riwayat Checkout</h2>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <table class="table table-striped table-bordered" id="historyTable">
            <thead>
                <tr>
                    <th>Nama Pembeli</th>
                    <th>Tanggal Pembelian</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $checkouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checkout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($checkout->buyer_name); ?></td>
                        <td><?php echo e($checkout->purchase_date); ?></td>
                        <td>
                            <a href="<?php echo e(route('history.show', $checkout->id)); ?>" class="btn btn-info">Detail</a>
                            <form action="<?php echo e(route('history.delete', $checkout->id)); ?>" method="POST"
                                style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger"
                                    onclick="return confirm('Apakah Anda yakin untuk menghapus data ini?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kasa\resources\views/history/index.blade.php ENDPATH**/ ?>